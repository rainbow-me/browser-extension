# @rainbow-me/delegation

## 1.0.0

### Major Changes

- Initial release with EIP-7702 delegation and batch transaction support
- Core interface:
  - `executeBatchedTransaction()`: Executes multiple calls in a single transaction using EIP-7702 delegation
  - `encodeDelegateCalldata`: Encode batch calls into delegation contract calldata
  - `getCanDelegate()`: Check if EIP-7702 delegation is supported on a specific chain
  - `getIsDelegated()`: Check if an address is currently delegated using EIP-7702
- Supported chains:
  - Ethereum Mainnet (1)
  - Polygon (137)
  - Base (8453)
  - Optimism (10)
  - BNB Smart Chain (56)
  - Sepolia (11155111)
  - Optimism Sepolia (11155420)
