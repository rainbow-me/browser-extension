# Rainbow Delegation

[![npm version](https://badge.fury.io/js/@rainbow-me/delegation.svg)](https://www.npmjs.com/package/@rainbow-me/delegation)
[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

EIP-7702 batch transaction executor with delegation detection. This package provides utilities to execute batched transactions using EIP-7702 delegation.

## Installation

```bash
yarn add @rainbow-me/delegation
# or
npm install @rainbow-me/delegation
# or
pnpm add @rainbow-me/delegation
```

**Peer Dependencies:**

```bash
yarn add viem@^2.0.0
```

## Quick Start

```typescript
import { executeBatchedTransaction } from '@rainbow-me/delegation';
import { createWalletClient, createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';

// Setup clients
const account = privateKeyToAccount('0x...');
const publicClient = createPublicClient({
  chain: mainnet,
  transport: http(),
});
const walletClient = createWalletClient({
  account,
  chain: mainnet,
  transport: http(),
});

// Define your batch calls
const calls = [
  {
    to: '0x...', // Token contract
    value: 0n,
    data: '0x...', // approve() calldata
  },
  {
    to: '0x...', // DEX contract
    value: 0n,
    data: '0x...', // swap() calldata
  },
];

// Execute batched transaction
const result = await executeBatchedTransaction({
  calls,
  walletClient,
  publicClient,
  transactionOptions: {
    maxFeePerGas: '20000000000',
    maxPriorityFeePerGas: '1000000000',
    gasLimit: null, // Auto-estimate
  },
});

console.log('Transaction hash:', result.hash);
```

## API Reference

### `executeBatchedTransaction(params)`

Executes multiple calls in a single transaction using EIP-7702 delegation.

**Parameters:**

```typescript
interface ExecuteBatchedTransactionParams {
  calls: BatchCall[];
  walletClient: WalletClient;
  publicClient: PublicClient;
  transactionOptions: TransactionGasParamAmounts;
}

interface BatchCall {
  to: Address;
  value: bigint;
  data: `0x${string}`;
}

interface TransactionGasParamAmounts {
  maxFeePerGas: string;
  maxPriorityFeePerGas: string;
  gasLimit: bigint | null;
}
```

**Returns:**

```typescript
interface BatchExecutionResult {
  hash: `0x${string}`;
  type: 'v2' | 'v4';
}
```

- `hash`: The transaction hash
- `type`: Transaction type - `'v2'` for regular transactions (when already delegated), `'v4'` for EIP-7702 transactions (when delegation is needed)

### `encodeDelegateCalldata(calls)`

Encode batch calls into delegation contract calldata. This utility function is useful when you need the encoded calldata separately from executing the transaction.

**Parameters:**

```typescript
calls: BatchCall[]  // Array of calls to encode
```

**Returns:**

```typescript
Promise<`0x${string}`>; // Encoded calldata for the delegation contract
```

**Example:**

```typescript
import { encodeDelegateCalldata } from '@rainbow-me/delegation';

const calls = [
  { to: '0x...', value: 0n, data: '0x...' },
  { to: '0x...', value: 0n, data: '0x...' },
];

const calldata = await encodeDelegateCalldata(calls);
// Returns encoded calldata like: '0x...'
```

**Note:** This function encodes calls with `revertOnFailure: true`, meaning if any call in the batch fails, the entire transaction reverts.

### `getCanDelegate({ chainId })`

Check if EIP-7702 delegation is supported on a specific chain.

```typescript
const canDelegate = getCanDelegate({ chainId: 1 }); // true for Ethereum mainnet
```

### `getIsDelegated({ address, chainId, publicClient })`

Check if an address is currently delegated using EIP-7702.

```typescript
const isDelegated = await getIsDelegated({
  address: '0x...',
  chainId: 1,
  publicClient,
});
```

### `getAllDelegations({ address })`

Get all delegations for a wallet across all chains. Returns only chains where the wallet is actually delegated (RAINBOW_DELEGATED or THIRD_PARTY_DELEGATED).

**Parameters:**

```typescript
interface GetAllDelegationsParams {
  address: Address; // Wallet address to check delegations for
}
```

**Returns:**

```typescript
interface AllDelegationsResult {
  delegations: ChainDelegation[];
}

interface ChainDelegation {
  chainId: number;
  delegationStatus: DelegationStatus; // RAINBOW_DELEGATED or THIRD_PARTY_DELEGATED
  currentAddress: Address | null; // Current delegation contract address (null if not delegated to Rainbow)
  latestAddress: Address | null; // Latest Rainbow contract address (null if no update available)
  revokeReason: RevokeReason | null; // VULNERABILITY, BUG, or null
  updateReason: UpdateReason | null; // UPGRADE_AVAILABLE, RAINBOW_ONBOARDING, or null
}
```

**Example:**

```typescript
import { getAllDelegations } from '@rainbow-me/delegation';

const result = getAllDelegations({
  address: '0x...',
});

// result.delegations is an array of ChainDelegation objects
// Each object represents a delegation on a specific chain
for (const delegation of result.delegations) {
  console.log(`Chain ${delegation.chainId}: ${delegation.delegationStatus}`);
  if (delegation.revokeReason) {
    console.log(`  ⚠️ Revoke needed: ${delegation.revokeReason}`);
  }
  if (delegation.updateReason) {
    console.log(`  🔄 Update available: ${delegation.updateReason}`);
  }
}
```

**Note:** This function requires the platform client to be configured. Make sure to call `configure({ platformClient })` before using this function.

## Supported Chains

| Chain            | Chain ID | Status |
| ---------------- | -------- | ------ |
| Ethereum Mainnet | 1        | ✅     |
| Optimism         | 10       | ✅     |
| BSC              | 56       | ✅     |
| Gnosis           | 100      | ❌     |
| Unichain         | 130      | ✅     |
| Polygon          | 137      | ❌     |
| Monad            | 143      | ❌     |
| World Chain      | 480      | ❌     |
| Base             | 8453     | ✅     |
| Arbitrum         | 42161    | ✅     |
| Celo             | 42220    | ❌     |
| Ink              | 57073    | ❌     |
| Berachain        | 80094    | ❌     |
| Sepolia          | 11155111 | ✅     |
| Unichain Sepolia | 1301     | ✅     |

## How It Works

1. **Chain Validation**: Checks if the current chain supports EIP-7702 delegation
2. **Batch Encoding**: Encodes all calls as an atomic interaction with the contract batch interface
3. **Authorization**: Sign EIP-7702 authorization to delegate account to batch executor contract
4. **Gas Estimation**: Automatically estimates gas if not provided in `transactionOptions`
5. **Transaction Submission**: Send and execute the calls atomically in a single transaction with `authorizationList`

## How It's Used In Clients

1. **Chain Detection**: Checks if the current chain supports EIP-7702 delegation
2. **Delegation Check**: Verifies if the sender address is already delegated or needs re-delegation
3. **Smart Execution**:

   - If **not delegated**: Signs authorization + executes batch via delegation
   - If **already delegated**: Executes batch directly (no authorization needed)
   - If **chain unsupported**: Falls back to sequential transactions (raps)

4. **Transaction Types**:
   - **EIP-7702 Transaction** (type `0x04`): When authorization is needed
   - **Regular Transaction** (type `0x02`): When already delegated
   - **Sequential Transactions**: When delegation is unsupported

## Examples

### Token Approval + Swap

```typescript
import { encodeFunctionData } from 'viem';
import { executeBatchedTransaction } from '@rainbow-me/delegation';

const calls = [
  // Approve tokens
  {
    to: tokenAddress,
    value: 0n,
    data: encodeFunctionData({
      abi: erc20Abi,
      functionName: 'approve',
      args: [spenderAddress, amount],
    }),
  },
  // Execute swap
  {
    to: dexAddress,
    value: 0n,
    data: encodeFunctionData({
      abi: dexAbi,
      functionName: 'swapExactTokensForTokens',
      args: [amount, minOut, path, to, deadline],
    }),
  },
];

const result = await executeBatchedTransaction({
  calls,
  walletClient,
  publicClient,
  transactionOptions: {
    maxFeePerGas: '20000000000',
    maxPriorityFeePerGas: '1000000000',
    gasLimit: null,
  },
});
```

### Multi-Send ETH

```typescript
const calls = [
  { to: '0xAlice...', value: parseEther('0.1'), data: '0x' },
  { to: '0xBob...', value: parseEther('0.2'), data: '0x' },
  { to: '0xCharlie...', value: parseEther('0.05'), data: '0x' },
];

const result = await executeBatchedTransaction({
  calls,
  walletClient,
  publicClient,
  transactionOptions: {
    maxFeePerGas: '20000000000',
    maxPriorityFeePerGas: '1000000000',
    gasLimit: null,
  },
});
```

## Usage

```typescript
import {
  executeBatchedTransaction,
  getCanDelegate,
  getAllDelegations,
} from '@rainbow-me/delegation';
import { createWalletClient, createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';

// Create clients
const walletClient = createWalletClient({
  chain: mainnet,
  transport: http(),
  account: privateKeyToAccount('0x...'), // Your private key
});

const publicClient = createPublicClient({
  chain: mainnet,
  transport: http(),
});

// Check if delegation is supported
const canDelegate = getCanDelegate({ chainId: mainnet.id });
console.log(`Delegation supported on mainnet: ${canDelegate}`);

// Execute batch transaction
const result = await executeBatchedTransaction({
  calls: [
    {
      to: '0x742...abc', // Contract address
      data: '0x123...def', // Encoded function call
      value: 0n,
    },
    {
      to: '0x456...789',
      data: '0xabc...123',
      value: 100000000000000000n, // 0.1 ETH
    },
  ],
  walletClient,
  publicClient,
  transactionOptions: {
    maxFeePerGas: '20000000000',
    maxPriorityFeePerGas: '1000000000',
    gasLimit: null,
  },
});

console.log('Transaction submitted:', result.hash);

// Check all delegations across chains
const delegations = getAllDelegations({
  address: '0x...',
});

console.log(`Found ${delegations.delegations.length} delegations:`);
for (const delegation of delegations.delegations) {
  console.log(`Chain ${delegation.chainId}: ${delegation.delegationStatus}`);
}
```

### Key Features

- **EIP-7702 Delegation**: Detect delegation status and delegate if necessary
- **Batch Execution**: Uses EIP-7702 to batch multiple calls atomically
- **Gas Control**: Explicit gas parameter configuration
- **Automatic Estimation**: Gas limit estimated if not provided

## Development

```bash
# Install dependencies
yarn install

# Build the package
yarn build

# Run tests
yarn test

# Type check
yarn typecheck

# Watch mode
yarn dev
```

## License

GPL-3.0 © Rainbow

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request. By contributing to this project, you agree that your contributions will be licensed under the GPL-3.0 license.

## Links

- [EIP-7702 Specification](https://eips.ethereum.org/EIPS/eip-7702)
- [Viem Documentation](https://viem.sh)
- [GitHub Repository](https://github.com/rainbow-me/delegation)
