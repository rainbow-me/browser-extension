# Context & Dependency Injection

The library uses a type-safe dependency injection system that works with both viem and ethers.

## Architecture

```
context/
├── types.ts        # Services interface (PlatformClient, Logger)
├── container.ts    # Runtime container state & configure()
├── bind.ts         # bind(), bindAll(), Require<T>
├── index.ts        # Public exports
└── normalize/
    ├── index.ts    # NormalizableServices, normalize()
    ├── signer.ts   # Signer type, normalizeSigner()
    ├── provider.ts # Provider type, normalizeProvider()
    └── chains.ts   # Chain definitions
```

## Core Types

### Services (Container Services)

Container services are configured globally at app init:

```typescript
// types.ts
export interface Services {
  platformClient: PlatformClient;
  logger: Logger;
  // Add new container services here
}
```

### NormalizableServices

Normalizable services map keys to external input types. The output type is inferred from the input:

```typescript
// normalize/index.ts
export type NormalizableServices = {
  walletClient: Signer; // Signer → WalletClient
  publicClient: Provider; // Provider → PublicClient
};
```

### Require<T>

Pick services by their value types:

```typescript
Require<WalletClient | PublicClient>;
// = { walletClient: WalletClient; publicClient: PublicClient }

Require<PlatformClient>;
// = { platformClient: PlatformClient }

Require<Logger>;
// = { logger: Logger }
```

## Defining Functions

Functions declare dependencies using `Require<T>`:

```typescript
// getCanDelegate.ts
import type { Require, PlatformClient } from '../context';

export function getCanDelegate({
  platformClient,
  chainId,
}: { chainId: number } & Require<PlatformClient>): boolean {
  // platformClient injected from container
  return DELEGATION_ADDRESSES[chainId] !== undefined;
}
```

```typescript
// executeDelegation.ts
import type { Require } from '../context';
import { PublicClient, WalletClient } from 'viem';

export async function executeDelegation({
  walletClient,
  publicClient,
  calldata,
}: {
  calldata: Hex;
} & Require<WalletClient | PublicClient>) {
  // walletClient and publicClient are normalized viem clients
  const chainId = await publicClient.getChainId();
  // ...
}
```

## Binding Functions

### bind()

`bind()` wraps a function to:

1. Inject container services (e.g., `platformClient`, `logger`) automatically
2. Normalize client inputs (ethers `signer`/`provider` → viem `walletClient`/`publicClient`)

The wrapped function's parameter type is transformed via `Externalize<P>`:

- Container service keys are removed (injected automatically)
- Normalizable keys accept external input types (e.g., `Signer` instead of `WalletClient`)

### bindAll()

Use `bindAll()` to bind all functions at once in the index:

```typescript
// actions/index.ts
import { bindAll } from '../context';
import { getCanDelegate as _getCanDelegate } from './getCanDelegate';
import { executeDelegation as _executeDelegation } from './executeDelegation';

const actions = bindAll({
  getCanDelegate: _getCanDelegate,
  executeDelegation: _executeDelegation,
});

export const { getCanDelegate, executeDelegation } = actions;
```

## External API

Bound functions accept either viem or ethers clients:

```typescript
// Using viem clients
await executeDelegation({
  calldata: '0x...',
  walletClient,
  publicClient,
});

// Using ethers clients (normalized automatically)
await executeDelegation({
  calldata: '0x...',
  signer: ethersSigner,
  provider: ethersProvider,
  address: '0x...',
  chainId: 1,
});

// Container services injected automatically
getCanDelegate({ chainId: 1 });
```

## Configuration

Configure container services at app initialization:

```typescript
import { configure } from '@rainbow-me/delegation';

configure({
  platformClient: myHttpClient,
  logger: myLogger,
});
```

## Adding New Services

### Container Service

1. Define the interface in `types.ts`:

```typescript
export interface NewService {
  doSomething(): void;
}
```

2. Add to `Services` interface in `types.ts`:

```typescript
export interface Services {
  platformClient: PlatformClient;
  logger: Logger;
  newService: NewService; // Add here
}
```

3. Export the type from `index.ts`:

```typescript
export type { Services, PlatformClient, Logger, NewService } from './types';
```
